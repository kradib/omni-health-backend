package com.example.omni_health_app.service;

public interface INotificationService {

    void sendNotification(String to, String subject, String body);

}
