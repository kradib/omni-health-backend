package com.example.omni_health_app.util;

public final class Constants {

    public static final String CACHE_NAME = "resetTokens";

}
